import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';

void main() => runApp(const ObraFacilApp());

class ObraFacilApp extends StatelessWidget {
  const ObraFacilApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'ObraFácil',
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.orange),
    home: const HomePage(),
  );
}

class HomePage extends StatefulWidget { const HomePage({super.key}); @override State<HomePage> createState()=>_HomePageState(); }
class _HomePageState extends State<HomePage> {
  int index=0;
  final pages=[const Dashboard(), const CalculadorasPage(), const OrcamentoPage(), const ObrasPage()];
  @override Widget build(BuildContext context)=>Scaffold(
    body: SafeArea(child: pages[index]),
    bottomNavigationBar: NavigationBar(selectedIndex:index,onDestinationSelected:(i)=>setState(()=>index=i),destinations: const [
      NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Início'),
      NavigationDestination(icon:Icon(Icons.calculate_outlined),selectedIcon:Icon(Icons.calculate),label:'Calcular'),
      NavigationDestination(icon:Icon(Icons.receipt_long_outlined),selectedIcon:Icon(Icons.receipt_long),label:'Orçamento'),
      NavigationDestination(icon:Icon(Icons.construction_outlined),selectedIcon:Icon(Icons.construction),label:'Minhas obras'),
    ]));
}

class Dashboard extends StatelessWidget { const Dashboard({super.key});
  @override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.all(20),child:ListView(children:[
    const SizedBox(height:12), Text('🏗️ ObraFácil',style:Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight:FontWeight.bold)),
    const Text('Calcule. Planeje. Construa.'), const SizedBox(height:24),
    Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text('Seu assistente de obra',style:Theme.of(context).textTheme.titleLarge),const SizedBox(height:8),
      const Text('Calcule materiais e organize seus custos em Meticais.'),const SizedBox(height:14),
      FilledButton.icon(onPressed:()=>Navigator.of(context).push(MaterialPageRoute(builder:(_)=>const CalculadorasPage())),icon:const Icon(Icons.calculate),label:const Text('Começar a calcular'))
    ]))), const SizedBox(height:16),
    const Feature(icon:Icons.view_module,title:'Materiais',text:'Blocos, cimento, areia, brita, cerâmica e tinta.'),
    const Feature(icon:Icons.receipt_long,title:'Orçamento',text:'Adicione materiais e acompanhe o total em MT.'),
    const Feature(icon:Icons.home_work,title:'Minha obra',text:'Guarde projetos e acompanhe gastos.'),
  ]));
}
class Feature extends StatelessWidget { final IconData icon; final String title,text; const Feature({super.key,required this.icon,required this.title,required this.text});
  @override Widget build(BuildContext c)=>Card(child:ListTile(leading:CircleAvatar(child:Icon(icon)),title:Text(title),subtitle:Text(text)));
}

class CalculadorasPage extends StatefulWidget { const CalculadorasPage({super.key}); @override State<CalculadorasPage> createState()=>_CalculadorasPageState(); }
class _CalculadorasPageState extends State<CalculadorasPage>{
  final length=TextEditingController(text:'10'), height=TextEditingController(text:'3'), openings=TextEditingController(text:'2'), waste=TextEditingController(text:'5');
  String result='';
  void calcBlocks(){final l=double.tryParse(length.text.replaceAll(',','.'))??0,h=double.tryParse(height.text.replaceAll(',','.'))??0,o=double.tryParse(openings.text.replaceAll(',','.'))??0,w=double.tryParse(waste.text.replaceAll(',','.'))??5; final area=max0(l*h-o*2); final base=area*10; final total=(base*(1+w/100)).ceil(); setState(()=>result='Área estimada: ${area.toStringAsFixed(1)} m²\nBlocos: ~${base.ceil()}\nCom desperdício: $total blocos');}
  double max0(double n)=>n<0?0:n;
  @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(20),children:[Text('Calculadoras',style:Theme.of(c).textTheme.headlineMedium?.copyWith(fontWeight:FontWeight.bold)),const SizedBox(height:16),
    Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('🧱 Blocos',style:Theme.of(c).textTheme.titleLarge),const SizedBox(height:12),
      field('Comprimento da parede (m)',length),field('Altura da parede (m)',height),field('Área de portas/janelas (m²)',openings),field('Desperdício (%)',waste),
      FilledButton.icon(onPressed:calcBlocks,icon:const Icon(Icons.calculate),label:const Text('Calcular')),if(result.isNotEmpty)...[const SizedBox(height:16),Container(width:double.infinity,padding:const EdgeInsets.all(14),decoration:BoxDecoration(borderRadius:BorderRadius.circular(12),color:Theme.of(c).colorScheme.surfaceContainerHighest),child:Text(result,style:const TextStyle(fontSize:16,fontWeight:FontWeight.w600)))] ]))),const SizedBox(height:14),
    const MaterialInfo(title:'🪣 Cimento',text:'Para estimativas de cimento, informe o traço e o volume de betão/argamassa desejado. Esta V1 prepara a estrutura para cálculos mais avançados.'),
    const MaterialInfo(title:'🏖️ Areia e 🪨 Brita',text:'Os cálculos avançados por volume serão adicionados na próxima versão.'),
    const MaterialInfo(title:'🎨 Tinta e 🟫 Cerâmica',text:'Use a área em m² e o rendimento indicado pelo fabricante para obter uma estimativa.'),
  ]);
  Widget field(String label,TextEditingController ctl)=>Padding(padding:const EdgeInsets.only(bottom:10),child:TextField(controller:ctl,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:InputDecoration(labelText:label,border:const OutlineInputBorder())));
}
class MaterialInfo extends StatelessWidget {final String title,text;const MaterialInfo({super.key,required this.title,required this.text}); @override Widget build(BuildContext c)=>Card(child:ListTile(title:Text(title),subtitle:Text(text)));}

class Item {String name; double qty,price; Item(this.name,this.qty,this.price); Map<String,dynamic> toJson()=>{'name':name,'qty':qty,'price':price}; factory Item.fromJson(Map<String,dynamic> j)=>Item(j['name'],(j['qty'] as num).toDouble(),(j['price'] as num).toDouble());}
class OrcamentoPage extends StatefulWidget {const OrcamentoPage({super.key});@override State<OrcamentoPage> createState()=>_OrcamentoPageState();}
class _OrcamentoPageState extends State<OrcamentoPage>{final name=TextEditingController();final qty=TextEditingController(text:'1');final price=TextEditingController();final labor=TextEditingController(text:'0');List<Item> items=[];
 double get total=>items.fold(0,(s,i)=>s+i.qty*i.price)+(double.tryParse(labor.text.replaceAll(',','.'))??0);
 void add(){final p=double.tryParse(price.text.replaceAll(',','.'))??0,q=double.tryParse(qty.text.replaceAll(',','.'))??0;if(name.text.trim().isEmpty||p<=0||q<=0)return;setState((){items.add(Item(name.text.trim(),q,p));name.clear();qty.text='1';price.clear();});}
 @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(20),children:[Text('Orçamento',style:Theme.of(c).textTheme.headlineMedium?.copyWith(fontWeight:FontWeight.bold)),const SizedBox(height:16),TextField(controller:name,decoration:const InputDecoration(labelText:'Material',border:OutlineInputBorder())),const SizedBox(height:10),Row(children:[Expanded(child:TextField(controller:qty,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Quantidade',border:OutlineInputBorder()))),const SizedBox(width:10),Expanded(child:TextField(controller:price,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Preço unitário (MT)',border:OutlineInputBorder())))]),const SizedBox(height:10),FilledButton.icon(onPressed:add,icon:const Icon(Icons.add),label:const Text('Adicionar material')),const SizedBox(height:14),
 ...items.asMap().entries.map((e)=>Card(child:ListTile(title:Text(e.value.name),subtitle:Text('${e.value.qty} × ${money(e.value.price)} MT'),trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:()=>setState(()=>items.removeAt(e.key))))),),const SizedBox(height:10),TextField(controller:labor,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Mão de obra (MT)',border:OutlineInputBorder()),onChanged:(_)=>setState((){})),const SizedBox(height:18),Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(children:[const Text('TOTAL ESTIMADO',style:TextStyle(fontWeight:FontWeight.bold)),Text('${money(total)} MT',style:Theme.of(c).textTheme.headlineSmall?.copyWith(fontWeight:FontWeight.bold)),const SizedBox(height:8),Text('${items.length} item(ns) + mão de obra')]))),FilledButton.icon(onPressed:()=>saveBudget(),icon:const Icon(Icons.save),label:const Text('Guardar orçamento'))]);
 String money(double n)=>NumberFormat('#,##0.00','pt').format(n);
 Future<void> saveBudget()async{final p=await SharedPreferences.getInstance();await p.setString('last_budget',jsonEncode({'items':items.map((e)=>e.toJson()).toList(),'labor':double.tryParse(labor.text)??0,'total':total}));if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Orçamento guardado neste aparelho.')));}
}
class ObrasPage extends StatefulWidget{const ObrasPage({super.key});@override State<ObrasPage> createState()=>_ObrasPageState();}
class _ObrasPageState extends State<ObrasPage>{final project=TextEditingController();final budget=TextEditingController();final spent=TextEditingController();String saved='';Future<void>save()async{final p=await SharedPreferences.getInstance();await p.setString('obra',jsonEncode({'name':project.text,'budget':budget.text,'spent':spent.text}));setState(()=>saved='Obra guardada.');}Future<void>load()async{final p=await SharedPreferences.getInstance();final s=p.getString('obra');if(s!=null){final j=jsonDecode(s);project.text=j['name'];budget.text=j['budget'];spent.text=j['spent'];setState((){});}}@override void initState(){super.initState();load();}@override Widget build(BuildContext c){final b=double.tryParse(budget.text.replaceAll(',','.'))??0,s=double.tryParse(spent.text.replaceAll(',','.'))??0;final balance=b-s;return ListView(padding:const EdgeInsets.all(20),children:[Text('Minhas obras',style:Theme.of(c).textTheme.headlineMedium?.copyWith(fontWeight:FontWeight.bold)),const SizedBox(height:16),TextField(controller:project,decoration:const InputDecoration(labelText:'Nome da obra',border:OutlineInputBorder())),const SizedBox(height:10),TextField(controller:budget,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Orçamento previsto (MT)',border:OutlineInputBorder()),onChanged:(_)=>setState((){})),const SizedBox(height:10),TextField(controller:spent,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Gasto atual (MT)',border:OutlineInputBorder()),onChanged:(_)=>setState((){})),const SizedBox(height:14),Card(child:ListTile(title:Text(project.text.isEmpty?'Minha obra':project.text),subtitle:Text('Orçamento: ${money(b)} MT\nGasto: ${money(s)} MT\nSaldo: ${money(balance)} MT'))),FilledButton.icon(onPressed:save,icon:const Icon(Icons.save),label:const Text('Guardar obra')),if(saved.isNotEmpty)Padding(padding:const EdgeInsets.all(8),child:Text(saved));}String money(double n)=>NumberFormat('#,##0.00','pt').format(n);}
