# ObraFácil — MVP Android

Aplicativo Flutter para construção civil, focado inicialmente em Moçambique e valores em MT.

## V1 incluída
- Dashboard
- Calculadora de blocos
- Orçamento de materiais + mão de obra
- Guardar orçamento localmente
- Minha obra: orçamento, gasto e saldo
- Interface responsiva para celular

## Como executar
1. Instale Flutter e Android Studio.
2. Na pasta do projeto, rode `flutter pub get`.
3. Conecte um Android ou inicie um emulador.
4. Rode `flutter run`.
5. Para gerar APK: `flutter build apk --release`.

## Próximas versões
- Calculadoras de cimento/areia/brita/cerâmica/tinta com fórmulas configuráveis.
- Exportar orçamento em PDF.
- Partilhar via WhatsApp.
- Cadastro de profissionais e lojas.
- Catálogo de preços por cidade.
- Login e sincronização em nuvem.
